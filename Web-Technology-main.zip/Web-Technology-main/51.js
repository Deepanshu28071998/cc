const obj = { name: "John", age: 30 };
const objToString = JSON.stringify(obj);
console.log(objToString);
