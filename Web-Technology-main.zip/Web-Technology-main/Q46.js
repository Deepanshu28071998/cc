// 46. JavaScript Program to Display Date and Time
console.log(new Date().toString());
