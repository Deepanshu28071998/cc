// Write a JavaScript Program to Convert Celsius to Fahrenheit
function celsiusToFahrenheit(celsius) {
    return (celsius * 9/5) + 32;
}

let celsius = 25;
console.log(celsius + "°C is " + celsiusToFahrenheit(celsius) + "°F");
