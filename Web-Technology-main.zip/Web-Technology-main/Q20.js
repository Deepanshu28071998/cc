// Write a JavaScript Program to Calculate the Area of a Triangle.
function calculateTriangleArea(base, height) {
    return 0.5 * base * height;
}

let base = 5;
let height = 10;
console.log("Area of Triangle: " + calculateTriangleArea(base, height));

