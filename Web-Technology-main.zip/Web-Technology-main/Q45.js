// 45. JavaScript Program to Add Key/Value Pair to an Object
const person = { name: "Alice" };
person.age = 25;
console.log(person);
