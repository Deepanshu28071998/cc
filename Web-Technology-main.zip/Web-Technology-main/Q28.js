// JavaScript Program to Display the Multiplication Table
function multiplicationTable(n) {
    for (let i = 1; i <= 10; i++) {
        console.log(`${n} * ${i} = ${n * i}`);
    }
}

let num = 5;
multiplicationTable(num);
