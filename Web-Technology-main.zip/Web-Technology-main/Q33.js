// 33. JavaScript Program to Set a Default Parameter Value for a Function
function greet(name = "Guest") {
    console.log(`Hello, ${name}!`);
}
greet();
