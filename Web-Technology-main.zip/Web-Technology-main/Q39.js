// 39. Write a program to create dialogue boxes using JavaScript.
alert("This is an alert box!");
const userResponse = confirm("Do you want to proceed?");
const userName = prompt("Please enter your name:");
console.log(`Response: ${userResponse}, Name: ${userName}`);
