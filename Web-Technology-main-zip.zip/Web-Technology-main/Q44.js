// 44. JavaScript Program to Check if a Key Exists in an Object
const person = { name: "Alice" };
console.log("age" in person); // Output: false
