//Q.17 Write a JavaScript Program to Print Hello World.
console.log("Hello World");
