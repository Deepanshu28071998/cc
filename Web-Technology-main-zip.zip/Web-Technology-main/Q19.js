//Q19. Write a JavaScript Program to Find the Square Root.

function findSquareRoot(num) {
    return Math.sqrt(num);
}

let number = 16;
console.log("Square Root: " + findSquareRoot(number));
