// 43. JavaScript Program to Remove a Property from an Object
const person = { name: "Alice", age: 25 };
delete person.age;
console.log(person);
