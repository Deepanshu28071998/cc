// Write a JavaScript Program to Convert Decimal to Binary
function decimalToBinary(decimal) {
    return decimal.toString(2);
}

let decimal = 10;
console.log("Binary: " + decimalToBinary(decimal));
