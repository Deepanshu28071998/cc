// 49. JavaScript Program to Display Current Date
const today = new Date();
console.log(today.toDateString());
