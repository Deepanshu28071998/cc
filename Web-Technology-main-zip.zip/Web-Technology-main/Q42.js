// 42. JavaScript Program to Merge Property of Two Objects
const objA = { name: "Alice" };
const objB = { age: 25 };
const merged = { ...objA, ...objB };
console.log(merged);
