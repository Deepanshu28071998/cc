//Q18. Write a JavaScript Program to Add Two Numbers.
function addTwoNumbers(a, b) {
    return a + b;
}
let num1 = 5;
let num2 = 10;
console.log("Sum: " + addTwoNumbers(num1, num2));
